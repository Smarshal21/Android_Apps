package com.sammycode.notesample.models

data class NoteRequest(
    val title: String,
    val description: String
)