package com.sammycode.notesample.models

data class UserResponse(
    val token: String,
    val user: User
)