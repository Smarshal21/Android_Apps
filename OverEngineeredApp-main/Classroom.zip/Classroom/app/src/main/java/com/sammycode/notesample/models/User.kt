package com.sammycode.notesample.models

data class User(
    val createdAt: String,
    val email: String,
    val id: String,
    val updatedAt: String,
    val username: String
)